#!/usr/local/bin/jython
# -*- coding: utf-8 -*-

"""
ZetCode Jython Swing tutorial

This program creates a quit
button. When we press the button,
the application terminates.

author: Jan Bodnar
website: www.zetcode.com
last modified: November 2010
"""

from java.lang import System
from javax.swing import JButton
from javax.swing import JFrame
from javax.swing import JPanel


class Gui(JFrame):
    def __init__(self):
        super(Gui, self).__init__()

        self.initUI()

    def initUI(self):

        panel = JPanel()
        self.getContentPane().add(panel)

        panel.setLayout(None)

        qbutton = JButton("Anwendung beenden", actionPerformed=self.onQuit)
        qbutton.setBounds(50, 60, 150, 30)

        panel.add(qbutton)

        self.setTitle("Jython GUI mit Swing")
        self.setSize(300, 200)
        self.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
        self.setLocationRelativeTo(None)
        self.setVisible(True)

    def onQuit(self, e):
        System.exit(0)


if __name__ == '__main__':
    Gui()