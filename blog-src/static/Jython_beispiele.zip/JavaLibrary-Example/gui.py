import sys
sys.path.append("C:\\Users\\oschmitt\\Desktop\\JavaLibrary-Example\\TestLibrary.jar")
from fancy import HelloWorldFrame

class Gui():
    def __init__(self):
        HelloWorldFrame()
		
if __name__ == '__main__':
    Gui()