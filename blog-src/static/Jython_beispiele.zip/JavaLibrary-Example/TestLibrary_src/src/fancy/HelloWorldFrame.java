package fancy;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class HelloWorldFrame extends JFrame {

	private static final long serialVersionUID = 4613769918704428993L;
	private JLabel jlbHelloWorld;

	public HelloWorldFrame() {
		this.jlbHelloWorld = new JLabel("Hello World");
		this.add(jlbHelloWorld);
		this.setSize(100, 100);
		this.setVisible(true);
	}
	
	public static void main(String[] args){
		new HelloWorldFrame();
	}
}
