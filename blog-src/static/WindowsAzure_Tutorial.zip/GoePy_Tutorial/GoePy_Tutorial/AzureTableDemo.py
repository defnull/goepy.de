from azure.storage import *
import os
import base64

# Entwicklerschluessel fuer den lokalen Storage Emulator setzen
emulator_account_name = 'devstoreaccount1'
emulator_key = 'Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw=='

# Umgebungsvariablen setzen
os.environ['EMULATED'] = '1'
os.environ['AZURE_STORAGE_ACCOUNT'] = emulator_account_name
os.environ['AZURE_STORAGE_ACCESS_KEY'] = emulator_key

class AzureTableDemo(object):
    """description of class"""

    def __init__(self):
        self.azure_table_service = TableService()
        self.azure_table_service.use_local_storage = True

    def createTable(self, table_name):
        self.azure_table_service.create_table(table_name)

    def insert(self, table_name, entity):
        self.azure_table_service.insert_entity(table_name, entity)



tableTest = AzureTableDemo();
tableTest.createTable('tasktable');

task = Entity()
task.PartitionKey = 'aufgabenGoettingen'
task.RowKey = '2'
task.description = 'Waesche waschen'
task.priority = 100

tableTest.insert('tasktable', task)


