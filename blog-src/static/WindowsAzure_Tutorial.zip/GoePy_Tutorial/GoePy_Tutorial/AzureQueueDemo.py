from azure.storage import *
import os
import base64

# Entwicklerschluessel fuer den lokalen Storage Emulator setzen
emulator_account_name = 'devstoreaccount1'
emulator_key = 'Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw=='

# Umgebungsvariablen setzen
os.environ['EMULATED'] = '1'
os.environ['AZURE_STORAGE_ACCOUNT'] = emulator_account_name
os.environ['AZURE_STORAGE_ACCESS_KEY'] = emulator_key

# Verbindung 
azure_queue_service = QueueService()
azure_queue_service.use_local_storage = True

# Testqueue erzeugen
azure_queue_service.create_queue('testqueue')

# Nachricht in die Queue geben
azure_queue_service.put_message('testqueue','Ich bin der Nachrichtentext')

# Nachricht aus der Queue lesen
messages = azure_queue_service.get_messages('testqueue')
print "Nachrichten-ID: "  + messages[0].message_id
print "Nachrichtentext: "  + messages[0].message_text