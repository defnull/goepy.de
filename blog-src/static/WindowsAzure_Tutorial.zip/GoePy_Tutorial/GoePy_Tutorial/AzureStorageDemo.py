from azure.storage import *
import os
import base64

# Entwicklerschluessel fuer den lokalen Storage Emulator setzen
emulator_account_name = 'devstoreaccount1'
emulator_key = 'Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw=='

# Umgebungsvariablen setzen
os.environ['EMULATED'] = '1'
os.environ['AZURE_STORAGE_ACCOUNT'] = emulator_account_name
os.environ['AZURE_STORAGE_ACCESS_KEY'] = emulator_key

class AzureStorage(object):

    chunk_size = 0
    azure_blob_service = ''

    def __init__(self):
        self.chunk_size = 4 * 1024 * 1024
        self.azure_blob_service = BlobService()

    def createContainer(self, container_name, makepublic):
        # Container in Azure Storage erzeugen
        self.azure_blob_service.create_container(container_name)

        # Container fuer "alle" freigeben?
        if (makepublic):
            self.azure_blob_service.set_container_acl(container_name, x_ms_blob_public_access='container')


    def upload(self, container_name, blob_name, file_path):
        self.azure_blob_service.create_container(container_name, None, None, False)
        self.azure_blob_service.put_blob(container_name, blob_name, '', 'BlockBlob')

        block_ids = []
        index = 0
        with open(file_path, 'rb') as f:
            while True:
                data = f.read(self.chunk_size)
                if data:
                    length = len(data)
                    block_id = base64.b64encode(str(index))
                    self.azure_blob_service.put_block(container_name, blob_name, data, block_id)
                    block_ids.append(block_id)
                    index += 1
                else:
                    break

        self.azure_blob_service.put_block_list(container_name, blob_name, block_ids)

    def download(self, container_name, blob_name, file_path):
        props = self.azure_blob_service.get_blob_properties(container_name, blob_name)
        blob_size = int(props['content-length'])

        index = 0
        with open(file_path, 'wb') as f:
            while index < blob_size:
                chunk_range = 'bytes={}-{}'.format(index, index + self.chunk_size - 1)
                data = self.azure_blob_service.get_blob(container_name, blob_name, x_ms_range=chunk_range)
                length = len(data)
                index += length
                if length > 0:
                    f.write(data)
                    if length < self.chunk_size:
                        break
                else:
                    break

print 'Verbinde mit Azure Storage Space'
storageTest = AzureStorage()
print 'Erzeuge Container...'
storageTest.createContainer('testcontainer',True)
print 'Lade Datei Hoch...'
storageTest.upload('testcontainer','friendlytextfile','C:\Windows\Logs\IE10_HardwareCheck.log')
print 'fertig.'


